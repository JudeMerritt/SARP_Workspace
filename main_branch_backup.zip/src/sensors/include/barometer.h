/**
 * This file is part of the Titan Flight Computer Project
 * Copyright (c) 2025 UW SARP
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 * 
 * @file sensors/include/barometer.h
 * @authors Jude Merritt
 * @brief MS561101BA03 Barometer driver
 */

#pragma once
#include <stdint.h>
#include "periphs/include/spi.h"
#include "util/include/errc.h"

/**************************************************************************************************
 * @section Type definitions
 **************************************************************************************************/

/** 
 * @brief Oversampling ratios
 */
typedef enum {
    OSR_256  = 0x00, // 256 samples per measurement 
    OSR_512  = 0x02, // 512 samples per measurement 
    OSR_1024 = 0x04, // 1024 samples per measurement 
    OSR_2048 = 0x06, // 2048 samples per measurement 
    OSR_4096 = 0x08  // 4096 samples per measurement 
}barometer_osr_t;

/** 
 * @brief Configuration data
 */
typedef struct {
    uint16_t sens;     // C1 Presure sensitivity 
    uint16_t off;      // C2 Pressure offset
    uint16_t tcs;      // C3 Temperature coefficient of pressure sensitivity
    uint16_t tco;      // C4 Temperature coefficient of pressure offset
    uint16_t t_ref;    // C5 Reference temperature
    uint16_t tempsens; // C6 Temperature coefficient of the temperature 
}barometer_config_data_t; //TODO: Is it more acurate to call this barometer_calibration_data_t?

/** 
 * @brief Pressure and temperature results
 */
typedef struct {
    float pressure;    // Temperature compensated pressure from 10 mbar to 1200 mbar with 0.01 mbar resolution
    float temperature; // Temperature from -40 C to 85 C with 0.01 C resulution
}barometer_result_t;

/** 
 * @brief Barometer device struct
 */
typedef struct {
    spi_device_t device;                 // SPI instance and CS pin 
    barometer_osr_t osr;                 // Oversampling setting
    barometer_config_data_t config_data; // Device configuration
    barometer_result_t result;           // Result (pressure and temperature) //TODO: Take this out of the barometer_t struct and just create the result struct in your function then return a pointer to it.
} barometer_t;

/**************************************************************************************************
 * @section Function Definitions
 **************************************************************************************************/

/**
 * @brief Initializes the MS561101BA03 barometer and loads calibration data. 
 * 
 * @param dev pointer to the barometer_t structure
 * @return ti_errc_t TI_ERRC_NONE on success, or another error code on failure
 */
ti_errc_t barometer_init(barometer_t *dev);

/**
 * @brief Performs a conversion and calculates compensated pressure and temperature.
 * 
 * @param dev pointer to the barometer_t structure
 * @return ti_errc_t TI_ERRC_NONE on success, or another error code on failure
 */
ti_errc_t get_barometer_data(barometer_t *dev);